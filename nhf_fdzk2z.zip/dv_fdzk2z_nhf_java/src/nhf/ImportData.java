package nhf;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ImportData {

    /**
     * Importál egy adott txt fájlt amit egyesével hozzáad a listába.
     * 
     * @param file_name - String fájl nevet vár ami abszolút útvonal
     * 
     * @throws FileNotFoundException - Exception dobódhat ha a fájlt nem találja meg.
     */
    public static void importDataFormTxt(String file_name) throws FileNotFoundException{
        try{
            BufferedReader br = new BufferedReader(new FileReader(file_name));
            String[] t;
            String line = "", address = "", phone = "", email = "", bDay = "", name = "";
            
            while (line != null) {
                line = br.readLine();
                t = line.split(":");
                
                if(t[1].equals(" ")){ t[1] = ""; }
                
                switch(t[0]){
                    case "address": address = t[1]; break;
                    case "phone": phone = t[1]; break;
                    case "email": email = t[1]; break;
                    case "bDay": bDay = t[1]; break;
                    case "name":
                        name = t[1];
                        Contact.add(name, address, email, phone, bDay);
                        break;
                } 
            }
            br.close();
        }catch (Exception e) {}
    }
}
