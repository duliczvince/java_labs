package nhf;

import java.util.ArrayList;

public class Contact {
    private String name, address, email, phoneNumber, bDate;
    static ArrayList<Contact> contactsList = new ArrayList<>();
    
    public Contact(String name){ this.name = name; }
    public Contact(String name, String address, String email, String phoneNumber, String bDate) {
        this.name = name;
        this.address = address;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.bDate = bDate;
    }
    
    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getEmail() { return email; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getbDate() { return bDate; }

    public void setName(String name) { this.name = name; }
    public void setAddress(String address) { this.address = address; }
    public void setEmail(String email) { this.email = email; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public void setbDate(String bDate) { this.bDate = bDate; }
    
    /**
     * Hozzá adja a listához egy új névjegyet a paraméterek szerint.
     * 
     * @param name String name - név
     * @param address String address - cím
     * @param email String email
     * @param phoneNumber String phoneNumber - telszám
     * @param bDate String bDate - születésnap
     */
    protected static void add(String name, String address, String email, String phoneNumber, String bDate){
        contactsList.add(new Contact(name, address, email, phoneNumber, bDate));
    }
    
    /**
     * Adott String alapján törli a listából az adott nevűt.
     * Ha több ugyan olyan nevű van a legutolsó felvettet fogja törölni.
     * 
     * @param name - név Stringet vár
     */
    protected static void deleteItem(String name){
        for(int i = contactsList.size() - 1; i >= 0; i--){
            if(contactsList.get(i).getName().equals(name)){
                contactsList.remove(i);
                break;
            }
        }
    }
    
    /**
     * Kitörli az összes elemet a listából.
     */
    protected static void deleteAllItem(){ contactsList.clear(); }
    
    @Override
    public String toString() { return "Contact{" + "name=" + name + ", address=" + address + ", email=" + email + ", phoneNumber=" + phoneNumber + ", bDate=" + bDate + '}'; }
}
