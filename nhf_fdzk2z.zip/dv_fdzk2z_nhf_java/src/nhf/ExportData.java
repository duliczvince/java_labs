package nhf;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;

public class ExportData {

    /**
     * Ha van fájl megnyitva a mentéssel felülírja azt.
     * Mentés másként pedig új fájlt hozhat létre vagy felül írhat egy meglévőt.
     *
     * @param file_name - String fájl nevet vár ami abszolút útvonal
     * @throws FileNotFoundException - Exception dobódhat ha a fájlt nem találja meg.
     */
    public static void exportDataToExistsTxt(String file_name) throws FileNotFoundException{
        try{
            if(!file_name.endsWith(".txt")){ file_name += ".txt"; }
            try (FileWriter fw = new FileWriter(new File(file_name))) {
                for (Contact contactsList : Contact.contactsList) {
                    if(contactsList.getAddress().equals("")) { contactsList.setAddress(" "); }
                    if(contactsList.getPhoneNumber().equals("")) { contactsList.setPhoneNumber(" "); }
                    if(contactsList.getEmail().equals("")) { contactsList.setEmail(" "); }
                    if(contactsList.getbDate().equals("")) { contactsList.setbDate(" "); }
                    if(contactsList.getName().equals("")) { contactsList.setName(" "); }
                    
                    fw.write("address:" + contactsList.getAddress() + "\n");
                    fw.write("phone:" + contactsList.getPhoneNumber() + "\n");
                    fw.write("email:" + contactsList.getEmail() + "\n");
                    fw.write("bDay:" + contactsList.getbDate() + "\n");
                    fw.write("name:" + contactsList.getName() + "\n");
                }
                fw.close();
            }
        }catch(Exception e){}
    }
}
