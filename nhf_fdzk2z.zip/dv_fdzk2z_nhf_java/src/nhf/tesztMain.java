package nhf;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class tesztMain extends javax.swing.JFrame {
    private int LIST_INDEX = 0;
    private String SELECTED_rBTN = "name";
    private String SELECTED_FILE = "";
    private final DefaultListModel listModel;
    
    /**
     * lol az stdErr-re ha lefut.
     * ha nem akkor lolxd
     */
    public static final void foo(){
        System.err.println("lol");
    }
    
    /**
     * Új névjegyet vesz fel a listába csak egy nevet ad hozzá.
     * @see Contact add metódus
     */
    protected void addContactForm(){
        String name = JOptionPane.showInputDialog(null, "Új névjegy neve:", "Névjegy felvétele", JOptionPane.QUESTION_MESSAGE);
        
        if(name.equals("") || name.equals(" ")){
            JOptionPane.showMessageDialog(null, "Sikertelen felvétel", "Hiba", JOptionPane.ERROR_MESSAGE);
        }else{ Contact.add(name, "", "", "", "");
            listModel.addElement(name);
            jList1.setModel(listModel);
            mentesMaskent_menu_Item.setEnabled(true);
            JOptionPane.showMessageDialog(null, "Sikeres felvétel", "", JOptionPane.INFORMATION_MESSAGE); 
        }
    }
    
    /**
     * Kitörli az összes elemet a listModel-ből
     */
    protected void removeJListElements(){
        listModel.removeAllElements();
        mentes_menu_Item.setEnabled(false);
        mentesMaskent_menu_Item.setEnabled(false);
    }
    
    /**
     * Módosítás után frissíteni kell a listModel-t.
     */
    protected void refreshJListElements(){
        listModel.removeAllElements();
        for (Contact contactsList : Contact.contactsList) {
            listModel.addElement(contactsList.getName());
        }
        jList1.setModel(listModel);
        
        clearTxtFld();
    }
    
    /**
     * Kitörli az összes textFieldé értékét.
     */
    protected void clearTxtFld(){
        nev_txtFld.setText("");
        cim_txtFld.setText("");
        tel_txtFld.setText("");
        email_txtFld.setText("");
        bday_txtFld.setText("");
    }
    
    /**
     * Név szerint keres
     * 
     * @param isSearchAll Ha nem mindenben keresünk akkor törölni kell a listModelből az elemeket.
     */
    protected void searchInName(boolean isSearchAll){
        if(!isSearchAll){ removeJListElements(); }
        for (Contact contactsList : Contact.contactsList) {
            if (contactsList.getName().toLowerCase().contains(keres_txtFld.getText().toLowerCase())) {
                if(!listModel.contains(contactsList.getName())){
                    listModel.addElement(contactsList.getName());
                }
            }
        }
        jList1.setModel(listModel);
    }
    
    /**
     * Telefonszám szerint keres
     * 
     * @param isSearchAll Ha nem mindenben keresünk akkor törölni kell a listModelből az elemeket.
     */
    protected void searchInPhone(boolean isSearchAll){
        if(!isSearchAll){ removeJListElements(); }
        for (Contact contactsList : Contact.contactsList) {
            if (contactsList.getPhoneNumber().toLowerCase().contains(keres_txtFld.getText().toLowerCase())) {
                if(!listModel.contains(contactsList.getName())){
                    listModel.addElement(contactsList.getName());
                }
            }
        }
        jList1.setModel(listModel);
    }
    
    /**
     * Email szerint keres
     * 
     * @param isSearchAll Ha nem mindenben keresünk akkor törölni kell a listModelből az elemeket.
     */
    protected void searchInEmail(boolean isSearchAll){
        if(!isSearchAll){ removeJListElements(); }
        for (Contact contactsList : Contact.contactsList) {
            if (contactsList.getEmail().toLowerCase().contains(keres_txtFld.getText().toLowerCase())) {
                if(!listModel.contains(contactsList.getName())){
                    listModel.addElement(contactsList.getName());
                }
            }
        }
        jList1.setModel(listModel);
    }
    
    /**
     * Mindenben keres, amiben talált azt kilistázza.
     * 
     */
    protected void searchInAll(){
        removeJListElements();
        searchInName(true);
        searchInPhone(true);
        searchInEmail(true);
    }
    
    /**
     * Eset szét választás mi alapján keresünk.
     */
    protected void search(){
        switch(SELECTED_rBTN){
            case "name": searchInName(false); break;
            case "phone": searchInPhone(false); break;
            case "email": searchInEmail(false); break;
            case "minden": searchInAll(); break;
        }
    }
    
    
    
    /**********          FORM MENÜ ITEM-EK          **********/
    
    
    /**
     * Menüben a megnyitással lehet megnyitni egy txt fájlt.
     */
    protected void megnyitasBtn(){
        try {   
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
            
            FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt", "text");
            fileChooser.setFileFilter(filter);
            
            File selectedFile;
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) { 
                selectedFile = fileChooser.getSelectedFile();
            }else{ return; }
            
            SELECTED_FILE = selectedFile.getAbsolutePath();
            if(!SELECTED_FILE.contains(".txt")){ JOptionPane.showMessageDialog(null, "Hibás vagy nem létező fájl!", "Hibás fájl", JOptionPane.ERROR_MESSAGE); }

            Contact.deleteAllItem();
            ImportData.importDataFormTxt(selectedFile.getAbsolutePath());
            
            removeJListElements();
            refreshJListElements();
            
            mentes_menu_Item.setEnabled(true);
            mentesMaskent_menu_Item.setEnabled(true);
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Hibás vagy nem létező fájl!", "Hibás fájl", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Menüben a mentés felül írja a megnyitott fájlt.
     * Ha nincs megnyitva fájl ez a menü ki van kapcsolva.
     */
    protected void mentesMaskentBtn(){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Mentés másként");
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
        fileChooser.setFileFilter(filter);

        if (fileChooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION){
            try {
                File file = fileChooser.getSelectedFile();
                ExportData.exportDataToExistsTxt((String)file.getAbsolutePath());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "A mentés sikertelen volt!", "Mentés sikertelen", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    /**
     * Menüben a mentés felül írja a megnyitott fájlt.
     * Ha nincs megnyitva fájl ez a menü ki van kapcsolva.
     */
    protected void mentesBtn(){
        try {
            ExportData.exportDataToExistsTxt(SELECTED_FILE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "A mentés sikertelen volt!", "Mentés sikertelen", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Menüben a törléssel a listModel-ben kiválaszott elemet törli.
     * Ha nincs kiválasztva elem akkor az elsőt fogja törölni.
     */
    protected void torlesBtn(){
        try{
            Contact.deleteItem((String) listModel.getElementAt(LIST_INDEX));
            refreshJListElements(); 
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "A törlés sikertelen volt!", "Törlés sikertelen", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Módosít button eseménye.
     * Ezzel véglegesíti a módosítást.
     * 
     * @see Contact setName , setXY ...
     */
    protected void editBtn(){
        try{
            Contact.contactsList.get(LIST_INDEX).setName(nev_txtFld.getText());
            Contact.contactsList.get(LIST_INDEX).setAddress(cim_txtFld.getText());
            Contact.contactsList.get(LIST_INDEX).setPhoneNumber(tel_txtFld.getText());
            Contact.contactsList.get(LIST_INDEX).setEmail(email_txtFld.getText());
            Contact.contactsList.get(LIST_INDEX).setbDate(bday_txtFld.getText());
            refreshJListElements();
            clearTxtFld();
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "A módosítás sikertelen volt!", "Sikertelen módosítás", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Main method
     */
    public tesztMain(){
        this.listModel = new DefaultListModel();
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        keres_grp = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        keres_txtFld = new javax.swing.JTextField();
        name_rBtn = new javax.swing.JRadioButton();
        telefon_rBtn = new javax.swing.JRadioButton();
        email_rBtn = new javax.swing.JRadioButton();
        minden_rBtn = new javax.swing.JRadioButton();
        keres_btn = new javax.swing.JButton();
        keres_lbl = new javax.swing.JLabel();
        nevjegy_lbl = new javax.swing.JLabel();
        nev_txtFld = new javax.swing.JTextField();
        nev_lbl = new javax.swing.JLabel();
        cim_lbl = new javax.swing.JLabel();
        tel_lbl = new javax.swing.JLabel();
        email_lbl = new javax.swing.JLabel();
        bday_lbl = new javax.swing.JLabel();
        cim_txtFld = new javax.swing.JTextField();
        tel_txtFld = new javax.swing.JTextField();
        email_txtFld = new javax.swing.JTextField();
        bday_txtFld = new javax.swing.JTextField();
        edit_btn = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        fajl_foMenu = new javax.swing.JMenu();
        ujnevjegy_menu_Item = new javax.swing.JMenuItem();
        megnyitas_menu_Item = new javax.swing.JMenuItem();
        mentes_menu_Item = new javax.swing.JMenuItem();
        mentesMaskent_menu_Item = new javax.swing.JMenuItem();
        torles_menu_Item = new javax.swing.JMenuItem();
        info_foMenu = new javax.swing.JMenu();
        sugo_menu_Item = new javax.swing.JMenuItem();
        uml_menu_Item = new javax.swing.JMenuItem();
        about_menu_Item = new javax.swing.JMenuItem();
        userManual_menu_Item = new javax.swing.JCheckBoxMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Névjegyzék");

        jList1.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jList1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jList1);

        keres_txtFld.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                keres_txtFldKeyReleased(evt);
            }
        });

        keres_grp.add(name_rBtn);
        name_rBtn.setSelected(true);
        name_rBtn.setText("Név");
        name_rBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name_rBtnActionPerformed(evt);
            }
        });

        keres_grp.add(telefon_rBtn);
        telefon_rBtn.setText("Telefonszám");
        telefon_rBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telefon_rBtnActionPerformed(evt);
            }
        });

        keres_grp.add(email_rBtn);
        email_rBtn.setText("E-mail");
        email_rBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                email_rBtnActionPerformed(evt);
            }
        });

        keres_grp.add(minden_rBtn);
        minden_rBtn.setText("Mindenben");
        minden_rBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minden_rBtnActionPerformed(evt);
            }
        });

        keres_btn.setText("Keres");
        keres_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keres_btnActionPerformed(evt);
            }
        });

        keres_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        keres_lbl.setText("Keresés:");

        nevjegy_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        nevjegy_lbl.setText("Névjegy módosítása:");

        nev_lbl.setText("Név:");

        cim_lbl.setText("Cím:");

        tel_lbl.setText("Telefonszám:");

        email_lbl.setText("E-mail");

        bday_lbl.setText("Születésnap:");

        edit_btn.setText("Módosítás");
        edit_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_btnActionPerformed(evt);
            }
        });

        fajl_foMenu.setText("Fájl");
        fajl_foMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fajl_foMenuMouseClicked(evt);
            }
        });

        ujnevjegy_menu_Item.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        ujnevjegy_menu_Item.setText("Új névjegy");
        ujnevjegy_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ujnevjegy_menu_ItemActionPerformed(evt);
            }
        });
        fajl_foMenu.add(ujnevjegy_menu_Item);

        megnyitas_menu_Item.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        megnyitas_menu_Item.setText("Megnyitás");
        megnyitas_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                megnyitas_menu_ItemActionPerformed(evt);
            }
        });
        fajl_foMenu.add(megnyitas_menu_Item);

        mentes_menu_Item.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        mentes_menu_Item.setText("Mentés");
        mentes_menu_Item.setEnabled(false);
        mentes_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mentes_menu_ItemActionPerformed(evt);
            }
        });
        fajl_foMenu.add(mentes_menu_Item);

        mentesMaskent_menu_Item.setText("Mentés másként");
        mentesMaskent_menu_Item.setEnabled(false);
        mentesMaskent_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mentesMaskent_menu_ItemActionPerformed(evt);
            }
        });
        fajl_foMenu.add(mentesMaskent_menu_Item);

        torles_menu_Item.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        torles_menu_Item.setText("Törlés");
        torles_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                torles_menu_ItemActionPerformed(evt);
            }
        });
        fajl_foMenu.add(torles_menu_Item);

        jMenuBar1.add(fajl_foMenu);

        info_foMenu.setText("Súgó");

        sugo_menu_Item.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_MASK));
        sugo_menu_Item.setText("Javadoc");
        sugo_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sugo_menu_ItemActionPerformed(evt);
            }
        });
        info_foMenu.add(sugo_menu_Item);

        uml_menu_Item.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_MASK));
        uml_menu_Item.setText("UML Diagram");
        uml_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uml_menu_ItemActionPerformed(evt);
            }
        });
        info_foMenu.add(uml_menu_Item);

        about_menu_Item.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        about_menu_Item.setText("Program verzió");
        about_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                about_menu_ItemActionPerformed(evt);
            }
        });
        info_foMenu.add(about_menu_Item);

        userManual_menu_Item.setText("Felhasználói kézikönyv");
        userManual_menu_Item.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userManual_menu_ItemActionPerformed(evt);
            }
        });
        info_foMenu.add(userManual_menu_Item);

        jMenuBar1.add(info_foMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nev_lbl, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cim_lbl, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tel_lbl, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(email_lbl, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(bday_lbl, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nev_txtFld, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                            .addComponent(cim_txtFld)
                            .addComponent(tel_txtFld)
                            .addComponent(email_txtFld)
                            .addComponent(bday_txtFld)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addComponent(edit_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(keres_txtFld, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(keres_btn)
                                .addGap(392, 392, 392)
                                .addComponent(nevjegy_lbl))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(name_rBtn)
                                    .addComponent(telefon_rBtn))
                                .addGap(14, 14, 14)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(email_rBtn)
                                    .addComponent(minden_rBtn)))
                            .addComponent(keres_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(keres_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name_rBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(email_rBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(telefon_rBtn)
                    .addComponent(minden_rBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(keres_txtFld, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(keres_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nevjegy_lbl, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nev_txtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nev_lbl))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cim_lbl)
                            .addComponent(cim_txtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tel_lbl)
                            .addComponent(tel_txtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(email_lbl)
                            .addComponent(email_txtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bday_lbl)
                            .addComponent(bday_txtFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(41, 41, 41)
                        .addComponent(edit_btn)))
                .addGap(36, 36, 36))
        );

        getAccessibleContext().setAccessibleName("Teszt");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Keres button eseménye
     * 
     * @param evt 
     */
    private void keres_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keres_btnActionPerformed
        try{ search();
        }catch (Exception e) {}
    }//GEN-LAST:event_keres_btnActionPerformed

    /**
     * Ha a listába kattint valaki egyszer akkor kiválaszt egy névjegyet.
     * 
     * Dupla kattintásnál betölti az adatokat és módosítani lehet azokat.
     * 
     * @param evt 
     */
    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        try{
            JList list = (JList)evt.getSource();
            LIST_INDEX = list.locationToIndex(evt.getPoint());
            if (evt.getClickCount() == 2) {     
                nev_txtFld.setText(Contact.contactsList.get(LIST_INDEX).getName());
                cim_txtFld.setText(Contact.contactsList.get(LIST_INDEX).getAddress());
                tel_txtFld.setText(Contact.contactsList.get(LIST_INDEX).getPhoneNumber());
                email_txtFld.setText(Contact.contactsList.get(LIST_INDEX).getEmail());
                bday_txtFld.setText(Contact.contactsList.get(LIST_INDEX).getbDate());
            }
        }catch (Exception e) {}
    }//GEN-LAST:event_jList1MouseClicked

    /**
     * Módosít button eseménye.
     * Ezzel véglegesíti a módosítást.
     * 
     * @see Contact setName metódus, setXY ...
     * 
     * @param evt 
     */
    private void edit_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_btnActionPerformed
        editBtn();
    }//GEN-LAST:event_edit_btnActionPerformed

    /**
     * Email radio button select-je
     * 
     * @param evt 
     */
    private void email_rBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_email_rBtnActionPerformed
        SELECTED_rBTN = "email";
    }//GEN-LAST:event_email_rBtnActionPerformed

    /**
     * Telefon radio button select-je
     * 
     * @param evt 
     */
    private void telefon_rBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telefon_rBtnActionPerformed
        SELECTED_rBTN = "phone";
    }//GEN-LAST:event_telefon_rBtnActionPerformed

    /**
     * Minden radio button select-je
     * 
     * @param evt 
     */
    private void minden_rBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minden_rBtnActionPerformed
        SELECTED_rBTN = "minden";
    }//GEN-LAST:event_minden_rBtnActionPerformed

    /**
     * Név radio button select-je
     * 
     * @param evt 
     */
    private void name_rBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name_rBtnActionPerformed
        SELECTED_rBTN = "name";
    }//GEN-LAST:event_name_rBtnActionPerformed

    /**
     * Menüben új névjegyre kattintás, majd megjeleníti az új névjegy felvételét.
     * 
     * @param evt 
     */
    private void ujnevjegy_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ujnevjegy_menu_ItemActionPerformed
        try{
            addContactForm();
        }catch (Exception e){ }
        
    }//GEN-LAST:event_ujnevjegy_menu_ItemActionPerformed

    /**
     * Keres text field-ben változás történik úgy, hogy üres lesz "" / " ",
     * akkor frissíti a lista elemeit.
     * 
     * @param evt 
     */
    private void keres_txtFldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_keres_txtFldKeyReleased
        if(keres_txtFld.getText().equals("") || keres_txtFld.getText().equals(" ")){ refreshJListElements(); }
    }//GEN-LAST:event_keres_txtFldKeyReleased

    /**
     * Menüben a törléssel a listModel-ben kiválaszott elemet törli.
     * Ha nincs kiválasztva elem akkor az elsőt fogja törölni.
     * 
     * @param evt 
     */
    private void torles_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_torles_menu_ItemActionPerformed
        torlesBtn();
    }//GEN-LAST:event_torles_menu_ItemActionPerformed

    /**
     * About menü, semmi érdekes nincs itt.
     * 
     * @param evt 
     */
    private void about_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_about_menu_ItemActionPerformed
        JOptionPane.showMessageDialog(null, "Névjegyzék\nJava HF 2019\nAll credits goes to FDZK2Z - Vince Dulicz", "Névjegyzék v1.0", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_about_menu_ItemActionPerformed

    /**
     * Menüben a megnyitással lehet megnyitni egy txt fájlt.
     * 
     * @param evt 
     */
    private void megnyitas_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_megnyitas_menu_ItemActionPerformed
        megnyitasBtn();
    }//GEN-LAST:event_megnyitas_menu_ItemActionPerformed

    /**
     * Menüben a mentés felül írja a megnyitott fájlt.
     * Ha nincs megnyitva fájl ez a menü ki van kapcsolva.
     * 
     * @param evt 
     */
    private void mentes_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mentes_menu_ItemActionPerformed
        mentesBtn();
    }//GEN-LAST:event_mentes_menu_ItemActionPerformed

    /**
     * Mentés másként új fájlt hozhat létre.
     * Meglévőt felül írja.
     * 
     * @param evt 
     */
    private void mentesMaskent_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mentesMaskent_menu_ItemActionPerformed
        mentesMaskentBtn();
    }//GEN-LAST:event_mentesMaskent_menu_ItemActionPerformed

    /**
     * Fájlra kattintásnál  eldönti van-e valami a listában és ha nincs,
     * a mentés,-másként elérhetetlen.
     * 
     * @param evt 
     */
    private void fajl_foMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fajl_foMenuMouseClicked
        if(Contact.contactsList.isEmpty()){
            mentes_menu_Item.setEnabled(false);
            mentesMaskent_menu_Item.setEnabled(false);
        }
    }//GEN-LAST:event_fajl_foMenuMouseClicked

    /**
     * Megnyitja a javadoc-ot
     * 
     * @param evt 
     */
    private void sugo_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sugo_menu_ItemActionPerformed
        try {
            Desktop.getDesktop().browse(new URL("http://cucckombo.duliczvince.hu/javadoc/").toURI());
        } catch (URISyntaxException | IOException e) {}
    }//GEN-LAST:event_sugo_menu_ItemActionPerformed

    /**
     * UML Diagramot nyitja meg
     * 
     * @param evt 
     */
    private void uml_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uml_menu_ItemActionPerformed
        try {
            Desktop.getDesktop().browse(new URL("http://cucckombo.duliczvince.hu/whole_diagram.png").toURI());
        } catch (URISyntaxException | IOException e) {}
    }//GEN-LAST:event_uml_menu_ItemActionPerformed

    private void userManual_menu_ItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userManual_menu_ItemActionPerformed
        try {
            Desktop.getDesktop().browse(new URL("http://cucckombo.duliczvince.hu/user_manual.pdf").toURI());
        } catch (URISyntaxException | IOException e) {}
    }//GEN-LAST:event_userManual_menu_ItemActionPerformed

    /**
     * Main
     * 
     * @param args 
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tesztMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new tesztMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem about_menu_Item;
    private javax.swing.JLabel bday_lbl;
    private javax.swing.JTextField bday_txtFld;
    private javax.swing.JLabel cim_lbl;
    private javax.swing.JTextField cim_txtFld;
    private javax.swing.JButton edit_btn;
    private javax.swing.JLabel email_lbl;
    private javax.swing.JRadioButton email_rBtn;
    private javax.swing.JTextField email_txtFld;
    private javax.swing.JMenu fajl_foMenu;
    private javax.swing.JMenu info_foMenu;
    private javax.swing.JList jList1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton keres_btn;
    private javax.swing.ButtonGroup keres_grp;
    private javax.swing.JLabel keres_lbl;
    private javax.swing.JTextField keres_txtFld;
    private javax.swing.JMenuItem megnyitas_menu_Item;
    private javax.swing.JMenuItem mentesMaskent_menu_Item;
    private javax.swing.JMenuItem mentes_menu_Item;
    private javax.swing.JRadioButton minden_rBtn;
    private javax.swing.JRadioButton name_rBtn;
    private javax.swing.JLabel nev_lbl;
    private javax.swing.JTextField nev_txtFld;
    private javax.swing.JLabel nevjegy_lbl;
    private javax.swing.JMenuItem sugo_menu_Item;
    private javax.swing.JLabel tel_lbl;
    private javax.swing.JTextField tel_txtFld;
    private javax.swing.JRadioButton telefon_rBtn;
    private javax.swing.JMenuItem torles_menu_Item;
    private javax.swing.JMenuItem ujnevjegy_menu_Item;
    private javax.swing.JMenuItem uml_menu_Item;
    private javax.swing.JCheckBoxMenuItem userManual_menu_Item;
    // End of variables declaration//GEN-END:variables
}
