package teszt;

import nhf.ExportData;
import java.io.File;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ExportDataTest {
    File file;
    String f_name;
    
    @Before
    public void setUp() {
        file = new File("teszt.txt");
        f_name = "teszt";
    }
    
    /**
     * Test of exportDataToExistsTxt method, of class ExportData.
     * @throws java.lang.Exception
     */
    @Test
    public void testExportDataToExistsTxt() throws Exception {
        System.out.println("exportDataToExistsTxt");
        
        ExportData.exportDataToExistsTxt(f_name);
        boolean expectedResult = true;
        boolean actualResult = false;
        
        if (file.exists()){ actualResult = true; }
        assertEquals(expectedResult, actualResult);
    }
}
