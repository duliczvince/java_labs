package teszt;

import nhf.Contact;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.not;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;

public class ContactTest {
    Contact instance;
    ArrayList<Contact> contactsList;
    ArrayList<Contact> contactsList2;
    
    @Before
    public void setUp() {
        instance = new Contact("name", "address", "email", "phoneNumber", "bDate");
        contactsList = new ArrayList<>();
        contactsList2 = new ArrayList<>();
    }

    /**
     * Test of getName method, of class Contact.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        String expResult = "name";
        String result = instance.getName();
        assertEquals(expResult, result);
    }

    /**
     * Test of getAddress method, of class Contact.
     */
    @Test
    public void testGetAddress() {
        System.out.println("getAddress");
        String expResult = "address";
        String result = instance.getAddress();
        assertEquals(expResult, result);
    }

    /**
     * Test of getEmail method, of class Contact.
     */
    @Test
    public void testGetEmail() {
        System.out.println("getEmail");
        String expResult = "email";
        String result = instance.getEmail();
        assertEquals(expResult, result);
    }

    /**
     * Test of getPhoneNumber method, of class Contact.
     */
    @Test
    public void testGetPhoneNumber() {
        System.out.println("getPhoneNumber");
        String expResult = "phoneNumber";
        String result = instance.getPhoneNumber();
        assertEquals(expResult, result);
    }

    /**
     * Test of getbDate method, of class Contact.
     */
    @Test
    public void testGetbDate() {
        System.out.println("getbDate");
        String expResult = "bDate";
        String result = instance.getbDate();
        assertEquals(expResult, result);
    }

    /**
     * Test of setName method, of class Contact.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "sName";
        instance.setName(name);
        String result = instance.getName();
        String expResult = "sName";
        assertEquals(expResult, result);
    }

    /**
     * Test of setAddress method, of class Contact.
     */
    @Test
    public void testSetAddress() {
        System.out.println("setAddress");
        String address = "sAddress";
        instance.setAddress(address);
        String result = instance.getAddress();
        String expResult = "sAddress";
        assertEquals(expResult, result);
    }

    /**
     * Test of setEmail method, of class Contact.
     */
    @Test
    public void testSetEmail() {
        System.out.println("setEmail");
        String email = "sEmail";
        
        instance.setEmail(email);
        String result = instance.getEmail();
        String expResult = "sEmail";
        assertEquals(expResult, result);
    }

    /**
     * Test of setPhoneNumber method, of class Contact.
     */
    @Test
    public void testSetPhoneNumber() {
        System.out.println("setPhoneNumber");
        String phoneNumber = "sPhoneNumber";
        
        instance.setPhoneNumber(phoneNumber);
        String result = instance.getPhoneNumber();
        String expResult = "sPhoneNumber";
        assertEquals(expResult, result);
    }

    /**
     * Test of setbDate method, of class Contact.
     */
    @Test
    public void testSetbDate() {
        System.out.println("setbDate");
        String bDate = "sBDate";
        
        instance.setbDate(bDate);
        String result = instance.getbDate();
        String expResult = "sBDate";
        assertEquals(expResult, result);
    }

    /**
     * Test of add method, of class Contact.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        String name = "n";
        String address = "a";
        String email = "e";
        String phoneNumber = "p";
        String bDate = "b";
        Contact addContact = new Contact(name, address, email, phoneNumber, bDate);
        contactsList.add(addContact);
        //itt hibát kelk adnia assertEquals(contactsList, contactsList2);
        assertThat(contactsList, not(contactsList2));
    }

    /**
     * Test of deleteItem method, of class Contact.
     */
    @Test
    public void testDeleteItem() {
        System.out.println("deleteItem");
        contactsList.add(instance);
        contactsList.remove(0);
        assertTrue(contactsList.isEmpty());
    }

    /**
     * Test of deleteAllItem method, of class Contact.
     */
    @Test
    public void testDeleteAllItem() {
        System.out.println("deleteAllItem");
        contactsList.add(instance);
        contactsList.add(instance);
        contactsList.clear();
        assertTrue(contactsList.isEmpty());
    }
}
