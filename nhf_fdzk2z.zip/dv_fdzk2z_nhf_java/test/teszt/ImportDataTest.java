package teszt;

import java.io.File;
import org.junit.Test;
import static org.junit.Assert.*;

public class ImportDataTest {
    /**
     * Test of importDataFormTxt method, of class ImportData.
     * @throws java.lang.Exception
     */
    @Test
    public void testImportDataFormTxt() throws Exception {
        System.out.println("importDataFormTxt");
        ClassLoader classLoader = this.getClass().getClassLoader();
        File file = new File(classLoader.getResource("teszt.txt").getFile());
        assertTrue(file.exists());
    }
}
